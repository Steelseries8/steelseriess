package kz.aitu.oop.assignment6;

public interface iCoffeeTable {
    public void hasLegs();
    public void sitOn();
}
